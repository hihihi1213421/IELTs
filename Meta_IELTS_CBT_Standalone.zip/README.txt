Standalone Meta IELTS CBT Mock — README

Files:
- index.html  : open this file in Chrome or Edge to run the test (double-click).
- style.css   : layout and CBT-like styling.
- app.js      : core logic (questions embedded, responses saved to browser localStorage).
- questions.json is NOT used in this standalone build (questions embedded in app.js).

Why buttons didn't respond before:
- The previous build used fetch('questions.json') which is blocked by many browsers when opening files via file://.
- This standalone package embeds all questions so it works when you double-click index.html (no server needed).

Editing questions:
- For this standalone package, edit the QUESTIONS variable inside app.js (near top) — replace text there.
- If you prefer editable JSON, ask me and I'll make a version that reads questions.json but requires hosting via GitHub Pages or a local server.

About "real IELTS past papers":
- I cannot provide or distribute official past-year IELTS test content (copyrighted/licensed material).
- I can create authentic-style practice items that mimic IELTS format and difficulty, or integrate official materials you legally supply.

Saving & Reports:
- Student responses are stored in the browser (localStorage) on the PC where the test runs.
- Generate a printable report (Review → Generate Report) and save/print as PDF; then upload to your cloud or email to admin.
- For central collection across machines, I can add Google Sheets upload or a small server endpoint — tell me which you'd prefer.
